import streamlit as st
import pandas as pd
import io
import time

# Page configuration
st.set_page_config(
    page_title="AI Text Summarizer", 
    page_icon="🤖",
    layout="centered",
    initial_sidebar_state="collapsed"
)

# Initialize the summarization model
@st.cache_resource
def load_summarizer():
    """Load and cache the summarization model"""
    try:
        from transformers import pipeline
        import torch
        
        # Use DistilBART for efficient deployment
        summarizer = pipeline(
            "summarization",
            model="sshleifer/distilbart-cnn-12-6",
            torch_dtype=torch.float32
        )
        return summarizer, "transformer"
    except ImportError:
        st.warning("⚠️ Transformer libraries not available. Using fallback extractive summarization.")
        return None, "extractive"
    except Exception as e:
        st.warning(f"⚠️ Could not load transformer model: {str(e)}. Using fallback method.")
        return None, "extractive"

def generate_summary_transformer(text, length="medium", model=None):
    """Generate summary using transformer model"""
    if not model:
        return "Model not available"
    
    # Length configurations for transformer
    length_configs = {
        "short": {"max_length": 50, "min_length": 20},
        "medium": {"max_length": 100, "min_length": 40},
        "long": {"max_length": 150, "min_length": 60}
    }
    
    config = length_configs.get(length, length_configs["medium"])
    
    try:
        # Truncate text if too long for the model
        max_input_length = 1024
        if len(text.split()) > max_input_length:
            text = ' '.join(text.split()[:max_input_length])
        
        # Generate summary
        result = model(
            text,
            max_length=config["max_length"],
            min_length=config["min_length"],
            do_sample=False,
            truncation=True
        )
        
        return result[0]['summary_text']
    except Exception as e:
        return f"Error generating summary: {str(e)}"

def generate_summary_extractive(text, length="medium"):
    """Fallback extractive summarization"""
    import re
    
    # Length configurations for extractive
    length_configs = {
        "short": {"sentences": 2, "max_words": 60},
        "medium": {"sentences": 3, "max_words": 100},
        "long": {"sentences": 4, "max_words": 140}
    }
    
    config = length_configs.get(length, length_configs["medium"])
    
    # Simple sentence extraction
    sentences = re.split(r'(?<=[.!?])\s+', text)
    sentences = [s.strip() for s in sentences if s.strip() and len(s.split()) >= 5]
    
    if not sentences:
        return "Unable to extract meaningful sentences from text."
    
    # Score sentences based on position and word frequency
    scores = {}
    words = text.lower().split()
    word_freq = {}
    for word in words:
        word_freq[word] = word_freq.get(word, 0) + 1
    
    for i, sentence in enumerate(sentences):
        score = 0
        sent_words = sentence.lower().split()
        
        # Frequency-based scoring
        for word in sent_words:
            if len(word) > 3:
                score += word_freq.get(word, 0)
        
        # Position bonus (first sentences often important)
        if i < len(sentences) * 0.3:
            score *= 1.2
        
        # Normalize by sentence length
        if len(sent_words) > 0:
            score = score / len(sent_words)
        
        scores[i] = score
    
    # Select top sentences
    top_indices = sorted(scores.keys(), key=lambda x: scores[x], reverse=True)[:config["sentences"]]
    top_indices.sort()  # Maintain original order
    
    summary = '. '.join([sentences[i] for i in top_indices])
    
    # Truncate if too long
    words = summary.split()
    if len(words) > config["max_words"]:
        summary = ' '.join(words[:config["max_words"]]) + '...'
    
    return summary

def generate_summary(text, length="medium", model=None, model_type="transformer"):
    """Main summary generation function"""
    if model_type == "transformer" and model:
        return generate_summary_transformer(text, length, model)
    else:
        return generate_summary_extractive(text, length)

# Title and description
st.title("🤖 AI Text Summarizer")

# Load model
with st.spinner("Loading AI model..."):
    summarizer_model, model_type = load_summarizer()

if model_type == "transformer":
    st.success("✅ Transformer model (DistilBART) loaded successfully!")
    st.markdown("Advanced text summarization using DistilBART transformer model")
else:
    st.info("ℹ️ Using extractive summarization (demonstrating NLP concepts)")
    st.markdown("Text summarization using frequency-based extractive methods")

# Create tabs
tab1, tab2 = st.tabs(["📝 Single Article", "📊 Batch Processing"])

with tab1:
    st.header("Single Article Summarization")
    
    col1, col2 = st.columns([3, 1])
    
    with col1:
        article_text = st.text_area(
            "📝 Paste your article here",
            height=300,
            placeholder="Paste your article text here...",
            help="Enter the text you want to summarize using AI"
        )
    
    with col2:
        st.markdown("**Summary Settings**")
        length_option = st.selectbox(
            "📏 Summary Length",
            options=["short", "medium", "long"],
            index=1,
            help="Choose the desired length of your summary"
        )
        
        if model_type == "transformer":
            length_descriptions = {
                "short": "Brief (20-50 words)",
                "medium": "Balanced (40-100 words)", 
                "long": "Detailed (60-150 words)"
            }
        else:
            length_descriptions = {
                "short": "Brief (2 sentences)",
                "medium": "Balanced (3 sentences)", 
                "long": "Detailed (4 sentences)"
            }
        st.caption(length_descriptions[length_option])
    
    # Generate summary button
    if st.button("🚀 Generate AI Summary", type="primary"):
        if not article_text.strip():
            st.warning("⚠️ Please paste some text first.")
        elif len(article_text.split()) < 10:
            st.warning("⚠️ Text is too short. Please provide at least 10 words.")
        else:
            with st.spinner("🧠 AI is analyzing and summarizing..."):
                start_time = time.time()
                summary = generate_summary(article_text, length_option, summarizer_model, model_type)
                end_time = time.time()
            
            st.success("✅ AI Summary Generated!")
            
            # Display metrics
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("Original Words", len(article_text.split()))
            with col2:
                st.metric("Summary Words", len(summary.split()))
            with col3:
                compression_ratio = round((1 - len(summary.split()) / len(article_text.split())) * 100, 1)
                st.metric("Compression", f"{compression_ratio}%")
            
            # Display summary
            st.markdown("### 📄 AI Generated Summary")
            st.info(summary)
            
            # Processing time
            st.caption(f"⏱️ Processing time: {end_time - start_time:.2f} seconds")

with tab2:
    st.header("Batch Processing from CSV")
    
    # File upload
    uploaded_file = st.file_uploader(
        "📂 Upload CSV file",
        type=["csv"],
        help="Upload a CSV file containing articles to summarize with AI"
    )
    
    if uploaded_file is not None:
        try:
            # Read CSV
            df = pd.read_csv(uploaded_file)
            st.success("✅ File uploaded successfully!")
            
            # Preview
            st.markdown("### 📋 Data Preview")
            st.dataframe(df.head(), use_container_width=True)
            
            # Configuration
            col1, col2, col3 = st.columns(3)
            
            with col1:
                text_column = st.selectbox(
                    "📝 Select text column",
                    options=df.columns,
                    help="Choose the column containing text to summarize"
                )
            
            with col2:
                num_rows = st.slider(
                    "📊 Number of rows",
                    min_value=1,
                    max_value=min(len(df), 20),  # Limit for demo
                    value=min(5, len(df)),
                    help="Select how many rows to process"
                )
            
            with col3:
                batch_length = st.selectbox(
                    "📏 Summary length",
                    options=["short", "medium", "long"],
                    index=1,
                    help="Choose summary length for all articles"
                )
            
            # Process button
            if st.button("⚡ Generate AI Summaries", type="primary"):
                if text_column not in df.columns:
                    st.error("❌ Selected column not found.")
                else:
                    # Process articles
                    df_subset = df.head(num_rows).copy()
                    
                    progress_bar = st.progress(0)
                    status_text = st.empty()
                    
                    summaries = []
                    start_time = time.time()
                    
                    for i, text in enumerate(df_subset[text_column]):
                        # Update progress
                        progress = (i + 1) / len(df_subset)
                        progress_bar.progress(progress)
                        status_text.text(f"AI processing article {i+1} of {len(df_subset)}...")
                        
                        # Generate summary
                        if pd.isna(text) or not str(text).strip():
                            summary = "No text to summarize"
                        else:
                            summary = generate_summary(str(text), batch_length, summarizer_model, model_type)
                        
                        summaries.append(summary)
                    
                    # Add summaries to dataframe
                    df_subset['ai_summary'] = summaries
                    
                    # Clear progress
                    progress_bar.empty()
                    status_text.empty()
                    
                    # Show results
                    end_time = time.time()
                    
                    st.success("✅ AI batch processing completed!")
                    
                    # Metrics
                    col1, col2, col3 = st.columns(3)
                    with col1:
                        st.metric("Processed", len(df_subset))
                    with col2:
                        avg_compression = round(sum([
                            (1 - len(str(summ).split()) / max(len(str(orig).split()), 1)) * 100
                            for orig, summ in zip(df_subset[text_column], summaries)
                            if pd.notna(orig) and pd.notna(summ) and "Error" not in str(summ)
                        ]) / max(len(summaries), 1), 1)
                        st.metric("Avg Compression", f"{avg_compression}%")
                    with col3:
                        st.metric("Time", f"{end_time - start_time:.1f}s")
                    
                    # Display results
                    st.markdown("### 📊 AI Summary Results")
                    display_columns = [text_column, 'ai_summary']
                    st.dataframe(df_subset[display_columns], use_container_width=True)
                    
                    # Download option
                    csv_buffer = io.StringIO()
                    df_subset.to_csv(csv_buffer, index=False)
                    
                    st.download_button(
                        label="📥 Download AI Summaries as CSV",
                        data=csv_buffer.getvalue(),
                        file_name="ai_summarized_articles.csv",
                        mime="text/csv",
                        type="primary"
                    )
                    
        except Exception as e:
            st.error(f"❌ Error reading file: {str(e)}")

# Sample datasets section
st.markdown("---")
st.markdown("### 📚 Recommended Datasets")

col1, col2 = st.columns(2)

with col1:
    st.markdown("""
    **BBC News Dataset**
    - High-quality news articles
    - Multiple categories
    - [Download from Kaggle](https://www.kaggle.com/c/learn-ai-bbc)
    """)

with col2:
    st.markdown("""
    **CNN/DailyMail Dataset**
    - News articles with summaries
    - Large scale dataset
    - [Download from Kaggle](https://www.kaggle.com/gowrishankarp/newspaper-text-summarization-cnn-dailymail)
    """)

# Technical details
st.markdown("---")
if model_type == "transformer":
    st.markdown("""
    🔧 **Technical Details**: This app uses DistilBART-CNN model, 
    a lightweight transformer optimized for abstractive text summarization. 
    The model generates human-like summaries by understanding context and meaning.
    
    **Architecture**: Sequence-to-sequence transformer with encoder-decoder structure
    """)
else:
    st.markdown("""
    🔧 **Technical Details**: This demo uses extractive summarization with 
    frequency-based sentence scoring. In production, this would use transformer 
    models like BART, T5, or GPT for abstractive summarization.
    
    **Skills Demonstrated**: NLP preprocessing, sentence extraction, ranking algorithms
    """)

# Model info
st.markdown("### 🤖 Model Information")
if model_type == "transformer":
    st.success("✅ Using DistilBART-CNN transformer model for abstractive summarization")
else:
    st.info("ℹ️ Demonstrating extractive summarization concepts (transformer model requires additional setup)")