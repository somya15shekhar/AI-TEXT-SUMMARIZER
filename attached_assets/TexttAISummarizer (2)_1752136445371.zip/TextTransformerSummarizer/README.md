# AI Text Summarizer

A powerful text summarization application using Facebook's BART transformer model for generating concise, AI-powered summaries of long articles and documents.

## 🚀 Features

- **Advanced AI Summarization**: Uses Facebook's BART-large-CNN transformer model
- **Manual Text Input**: Paste articles directly for instant summarization
- **Batch CSV Processing**: Upload CSV files for bulk summarization
- **Configurable Length**: Choose between short, medium, and long summaries
- **Real-time Metrics**: Track compression ratios and processing time
- **Download Results**: Export summarized data as CSV

## 🤖 Technology Stack

- **Model**: Facebook BART-large-CNN (Sequence-to-sequence transformer)
- **Framework**: Streamlit for web interface
- **AI Library**: Hugging Face Transformers
- **Backend**: PyTorch for model inference
- **Skills Demonstrated**: 
  - Sequence-to-sequence models
  - Transformer architectures (BART)
  - Natural Language Processing
  - Web application deployment

## 📊 Supported Datasets

This application works great with:

- [BBC News Dataset](https://www.kaggle.com/c/learn-ai-bbc) - High-quality news articles across multiple categories
- [CNN/DailyMail Dataset](https://www.kaggle.com/gowrishankarp/newspaper-text-summarization-cnn-dailymail) - Large-scale news summarization dataset
- Any CSV file with text columns

## 🛠️ Installation

### Local Development

1. Clone the repository
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Run the application:
   ```bash
   streamlit run app.py
   ```

### Streamlit Cloud Deployment

1. Fork this repository
2. Connect to [Streamlit Cloud](https://share.streamlit.io)
3. Deploy with main file: `app.py`

## 📋 Requirements

```
streamlit>=1.28.0
pandas>=1.5.0
transformers>=4.21.0
torch>=1.12.0
sentencepiece>=0.1.97
```

## 🎯 How to Use

### Single Article Summarization
1. Navigate to the "Single Article" tab
2. Paste your article text
3. Select summary length (short/medium/long)
4. Click "Generate AI Summary"

### Batch Processing
1. Navigate to "Batch Processing" tab
2. Upload a CSV file with text column
3. Select the text column to summarize
4. Choose number of rows and summary length
5. Click "Generate AI Summaries"
6. Download results as CSV

## 🧠 Model Details

**BART (Bidirectional and Auto-Regressive Transformers)** is a denoising autoencoder for pretraining sequence-to-sequence models. The `facebook/bart-large-cnn` model is specifically fine-tuned for summarization tasks and excels at:

- Understanding context and meaning
- Generating coherent, human-like summaries  
- Maintaining important information while compressing text
- Handling various text formats and lengths

## 📈 Performance

- **Model Size**: ~400MB (automatically downloaded on first use)
- **Processing Speed**: 2-10 seconds per article (depending on length)
- **Compression Ratio**: Typically 60-80% size reduction
- **Quality**: State-of-the-art abstractive summarization

## 🔧 Technical Architecture

```
app.py                 # Main Streamlit application
├── Model Loading      # Cached BART model initialization
├── Single Article     # Individual text summarization
├── Batch Processing   # CSV file handling and bulk processing
└── UI Components      # Streamlit interface elements

requirements.txt       # Python dependencies
.streamlit/config.toml # Streamlit configuration
```

## 🎓 Educational Value

This project demonstrates:
- **Transformer Models**: Practical implementation of BART
- **Sequence-to-Sequence Learning**: Text-to-text generation
- **Model Deployment**: Production-ready AI application
- **Batch Processing**: Scalable data processing workflows
- **Web Development**: Interactive ML interfaces

## 🚀 Live Demo

Try the application: [Streamlit Cloud Link] (Deploy to get the link)

## 📝 License

This project is open-source and available under the MIT License.