# NLP Text Summarizer

## Overview

This is a Streamlit-based AI text summarization application that transforms long articles into concise summaries using improved extractive summarization techniques. The application supports both single article summarization and batch processing capabilities, with configurable summary lengths and intelligent sentence selection algorithms.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

The application follows a simple web-based architecture with the following components:

### Frontend Architecture
- **Streamlit Web Framework**: Provides an interactive web interface with a clean, user-friendly design
- **Tab-based Interface**: Organizes functionality into "Single Article" and "Batch Processing" tabs
- **Responsive Layout**: Uses Streamlit's column system for optimal display across devices

### Backend Architecture
- **Model Layer**: Encapsulates the AI summarization logic in a separate module
- **Pipeline Architecture**: Uses Hugging Face Transformers pipeline for model inference
- **Memory Management**: Implements singleton pattern for model loading and garbage collection

## Key Components

### 1. Main Application (`app.py`)
- **Purpose**: Entry point and UI controller
- **Features**: 
  - Single article summarization interface
  - Summary length selection (short, medium, long)
  - Batch processing capability (tab structure prepared)
  - Clean, intuitive user interface

### 2. Summarizer Module (`model/summarizer.py`)
- **Purpose**: Core AI functionality for text summarization
- **Key Features**:
  - Text chunking for handling long articles
  - Singleton pattern for model instance management
  - Memory-optimized model loading
  - CPU-based inference for compatibility

### 3. Text Processing Pipeline
- **Sentence Extraction**: Improved regex-based sentence splitting with proper handling of abbreviations
- **Scoring Algorithm**: Multi-factor sentence scoring based on word frequency, position, and content quality
- **Length Control**: Configurable summary lengths with word limits and sentence constraints
- **Error Handling**: Graceful fallbacks for text processing failures

## Data Flow

1. **Input Processing**:
   - User enters text via Streamlit text area
   - Text is validated and cleaned
   - Long texts are chunked into manageable segments

2. **Summarization Process**:
   - Each chunk is processed through the Pegasus model
   - Partial summaries are generated for each chunk
   - Summaries are combined into final output

3. **Output Generation**:
   - Processed summary is displayed in the UI
   - Length settings influence the summarization parameters

## External Dependencies

### Core Libraries
- **Streamlit**: Web framework for the user interface
- **Transformers**: Hugging Face library for the Pegasus model
- **NLTK**: Natural language processing utilities for tokenization
- **PyTorch**: Deep learning framework (CPU mode)
- **Pandas**: Data manipulation (for batch processing)
- **Regex**: Advanced text processing

### AI Model
- **Google Pegasus XSUM**: Pre-trained abstractive summarization model
- **Model Size**: Large language model requiring significant memory
- **Inference Mode**: CPU-based for broader compatibility

## Deployment Strategy

### Current Configuration
- **Runtime**: CPU-based inference for maximum compatibility
- **Memory Management**: Singleton pattern to prevent model reloading
- **Error Handling**: Graceful degradation with fallback mechanisms

### Scalability Considerations
- **Model Caching**: Global model instance to avoid reloading
- **Memory Optimization**: Garbage collection and torch dtype optimization
- **Batch Processing**: Architecture prepared for handling multiple documents

### Performance Optimizations
- **Chunking Algorithm**: Preserves semantic meaning while managing token limits
- **Device Selection**: Automatic CPU fallback for environments without GPU
- **Resource Management**: Efficient memory usage through singleton pattern

## Recent Changes (January 2025)

### Major Algorithm Overhaul - Fixed Core Summarization Issues
**Date**: January 9, 2025
**Problem**: Users reported two critical issues:
1. Batch processing copying input text instead of summarizing
2. Fragmented sentence outputs instead of coherent summaries

**Solution**: Complete replacement of the summarization engine
- **Old System**: Complex Pegasus-based model with unreliable sentence extraction
- **New System**: Custom extractive summarization algorithm (`model/simple_summarizer.py`)

**Key Improvements**:
- **Robust Text Segmentation**: Multi-stage approach handling various text formats
- **Intelligent Content Selection**: Frequency-based scoring with position weighting
- **Coherent Output**: Ensures complete sentences and proper narrative flow  
- **Adaptive Length Control**: Better adherence to short/medium/long settings
- **Reliable Batch Processing**: Consistent performance across CSV uploads

**Technical Changes**:
- Replaced `model/summarizer.py` with `model/simple_summarizer.py`
- Updated app.py import statements
- Improved error handling and fallback mechanisms
- Enhanced text preprocessing for varied input formats

**User Impact**: 
- Batch processing now generates proper summaries instead of copying input
- Manual summarization produces coherent, meaningful summaries
- Better handling of poorly formatted text (news articles, social media, etc.)

## Key Architectural Decisions

### 1. Summarization Approach Pivot (January 2025)
- **Problem**: Complex transformer model causing unreliable sentence extraction and fragmented outputs
- **Solution**: Custom extractive algorithm with intelligent content selection
- **Rationale**: Reliability and coherence over theoretical sophistication
- **Trade-offs**: Simpler approach but much more predictable and useful results

### 2. Text Processing Strategy  
- **Problem**: Handling diverse text formats with varying punctuation and structure
- **Solution**: Multi-layered segmentation with fallback mechanisms
- **Rationale**: Real-world texts often lack perfect formatting
- **Alternative**: Strict sentence parsing (rejected due to fragmentation issues)

### 3. CPU-First Deployment
- **Problem**: GPU availability uncertainty in deployment environments
- **Solution**: CPU-optimized inference with memory management
- **Rationale**: Ensures broad compatibility across different hosting platforms
- **Trade-offs**: Slower inference speed but higher reliability

### 4. Streamlit Framework Choice
- **Problem**: Need for rapid prototyping and deployment
- **Solution**: Streamlit for web interface
- **Rationale**: Minimal configuration required, excellent for ML applications
- **Alternative**: Flask/Django (rejected due to complexity for this use case)