#!/usr/bin/env python3
"""
Script to prepare the project for Streamlit Cloud deployment.
Run this script to automatically clean up files for deployment.
"""

import os
import shutil

def prepare_deployment():
    """Clean up project for Streamlit Cloud deployment."""
    
    print("🚀 Preparing project for Streamlit Cloud deployment...")
    
    # Files to remove for deployment
    files_to_remove = [
        'pyproject.toml',
        'uv.lock',
        '.replit',
        'replit.md',
        'test_csv.csv',
        'prepare_for_deployment.py',  # This script itself
        'DEPLOYMENT_GUIDE.md',  # Not needed in production
        'model/summarizer.py'  # Old summarizer
    ]
    
    # Directories to remove
    dirs_to_remove = [
        'attached_assets',
        '__pycache__'
    ]
    
    # Remove files
    removed_files = []
    for file_path in files_to_remove:
        if os.path.exists(file_path):
            os.remove(file_path)
            removed_files.append(file_path)
            print(f"✅ Removed: {file_path}")
    
    # Remove directories
    for dir_path in dirs_to_remove:
        if os.path.exists(dir_path):
            shutil.rmtree(dir_path)
            removed_files.append(dir_path)
            print(f"✅ Removed directory: {dir_path}")
    
    # Rename streamlit_requirements.txt to requirements.txt
    if os.path.exists('streamlit_requirements.txt'):
        if os.path.exists('requirements.txt'):
            os.remove('requirements.txt')
        os.rename('streamlit_requirements.txt', 'requirements.txt')
        print("✅ Created requirements.txt")
    
    # Create requirements.txt if it doesn't exist
    if not os.path.exists('requirements.txt'):
        with open('requirements.txt', 'w') as f:
            f.write("streamlit>=1.28.0\npandas>=1.5.0\n")
        print("✅ Created requirements.txt")
    
    # List remaining files
    print("\n📁 Files ready for deployment:")
    remaining_files = []
    for root, dirs, files in os.walk('.'):
        # Skip hidden directories and __pycache__
        dirs[:] = [d for d in dirs if not d.startswith('.') and d != '__pycache__']
        
        for file in files:
            if not file.startswith('.') and not file.endswith('.pyc'):
                file_path = os.path.join(root, file)
                remaining_files.append(file_path)
    
    for file_path in sorted(remaining_files):
        print(f"  📄 {file_path}")
    
    print(f"\n🎉 Project cleaned! {len(removed_files)} files/directories removed.")
    print("📦 Your project is now ready for Streamlit Cloud deployment.")
    print("\n📋 Next steps:")
    print("1. Commit these changes to your GitHub repository")
    print("2. Go to share.streamlit.io")
    print("3. Connect your GitHub repository")
    print("4. Set main file to: app.py")
    print("5. Deploy!")

if __name__ == "__main__":
    prepare_deployment()